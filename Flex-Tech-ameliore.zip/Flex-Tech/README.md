# FlexTech

Site vitrine + catalogue pour FlexTech, revendeur de matériel informatique
au Sénégal (PC portables, PC gamer, PC bureau, moniteurs, accessoires,
composants). HTML/CSS/JS pur, aucune dépendance de build, aucun serveur
requis — s'héberge tel quel sur GitHub Pages, Vercel, Netlify ou Replit.

## Structure

```
index.html          Page d'accueil
produits.html        Catalogue complet (filtres, recherche, tri)
produit.html          Fiche produit dynamique (?id=)
contact.html          Formulaire de contact
assets/css/style.css        Styles principaux
assets/css/responsive.css   Media queries
assets/js/products.js       Catalogue produits + rendu des cartes
assets/js/app.js            Menu, filtres, animations, page produit
assets/images/products/     Photos produits (voir README dans ce dossier)
```

## Modifier le catalogue

Tout se passe dans `assets/js/products.js` : chaque produit est un objet
avec `id`, `name`, `category`, `price`, `oldPrice` (optionnel, pour une
promo), `specs`, `shortSpecs`, `description`, `rating`, `stock`.

Pour ajouter un produit : copie un objet existant, change l'`id` (unique),
remplis les champs. Il apparaît automatiquement dans le catalogue, les
filtres et la recherche.

## Ajouter les vraies photos

Voir `assets/images/products/README.md`.

## Numéro WhatsApp

Un seul endroit à changer : `WHATSAPP_NUMBER` en haut de
`assets/js/products.js`. Il est utilisé partout (cartes produits, fiche
produit, formulaire de contact, bouton flottant).

## Déploiement rapide

- **GitHub Pages** : Settings → Pages → Deploy from branch → `main` / `/root`.
- **Vercel/Netlify** : importer le repo, aucune configuration de build
  nécessaire (site statique).

## Sécurité

Ne jamais committer de token GitHub, clé API ou mot de passe dans ce
repo, même dans un message de commit ou un fichier de config. Utilise
les variables d'environnement de la plateforme d'hébergement si un
service tiers doit être connecté un jour.
