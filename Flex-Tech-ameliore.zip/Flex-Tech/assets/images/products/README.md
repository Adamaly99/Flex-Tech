# Comment ajouter tes vraies photos produits

Le site est câblé pour charger automatiquement une photo par produit, avec
un repli propre (icône du produit) tant que la photo n'existe pas.

## Convention de nommage

Pour chaque produit, ajoute un fichier ici nommé avec son `id` :

```
assets/images/products/1.jpg   → HP EliteBook 840 G8
assets/images/products/2.jpg   → Dell Latitude 5420
assets/images/products/3.jpg   → Lenovo ThinkPad X1 Carbon
assets/images/products/4.jpg   → PC Gamer FlexTech RTX 3060
...
```

La liste complète des id/produits est dans `assets/js/products.js`.

Formats acceptés : `.jpg` (recommandé), tu peux aussi utiliser `.png` ou
`.webp` mais il faudra alors changer l'extension dans la fonction
`getProductImageMarkup()` du fichier `assets/js/products.js`.

## Pourquoi pas de photos de stock des fabricants ?

Volontairement, je n'ai pas intégré de photos de HP/Dell/Lenovo trouvées
sur le web dans le repo : ce sont des images protégées par droit d'auteur,
et les insérer directement dans un site marchand sans licence claire est
risqué juridiquement pour toi en tant que revendeur.

**La bonne pratique, et aussi la plus efficace commercialement :**
photographie toi-même le matériel que tu as réellement en stock.
- Fond neutre (mur blanc, drap, ou même le sol carrelé bien éclairé)
- Lumière du jour, pas de flash direct
- Cadrage carré (1:1), l'appareil rempli 70-80% du cadre
- 1 photo par produit suffit pour démarrer

C'est aussi ce qui inspire le plus confiance à un client sénégalais :
il voit exactement ce qu'il va recevoir, pas une photo publicitaire
générique qui peut ne pas correspondre à l'état réel de l'appareil.

## Recommandation supplémentaire

Une fois que tu as 5-10 vraies photos, envoie-les moi (ou dépose-les
directement dans ce dossier via l'interface web de GitHub) et je peux
t'aider à les compresser/redimensionner pour que le site reste rapide.
