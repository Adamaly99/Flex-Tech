/* ========================================
   FLEXTECH — Catalogue produits
   Numéro WhatsApp unique pour toute commande.
   Remplace-le si besoin, une seule fois ici.
   ======================================== */

const WHATSAPP_NUMBER = "221785250503";

/* --------------------------------------
   Icônes SVG (une par catégorie).
   Servent de visuel tant qu'aucune vraie
   photo n'est présente dans
   assets/images/products/{id}.jpg
   -------------------------------------- */
const DEVICE_ICONS = {
  "PC Portables": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="8" y="9" width="32" height="21" rx="2"/><path d="M4 34h40l-3 5H7l-3-5Z"/><path d="M20 34h8"/></svg>`,
  "PC Bureau": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="6" y="8" width="24" height="18" rx="2"/><path d="M14 32h8m-4 0v-6"/><circle cx="38" cy="14" r="1.4" fill="currentColor" stroke="none"/><rect x="34" y="8" width="10" height="30" rx="2"/><path d="M37 32h4"/></svg>`,
  "PC Gamer": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="14" width="38" height="20" rx="4"/><circle cx="15" cy="24" r="3"/><path d="M13 24h4m-2-2v4"/><circle cx="31" cy="21" r="1.6" fill="currentColor" stroke="none"/><circle cx="35" cy="25" r="1.6" fill="currentColor" stroke="none"/></svg>`,
  "Moniteurs": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="8" width="38" height="24" rx="2"/><path d="M19 38h10m-5 0v-6"/><path d="M9 38h30"/></svg>`,
  "Claviers": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="14" width="38" height="20" rx="2"/><path d="M11 20h2m6 0h2m6 0h2m6 0h2M11 26h2m6 0h14m-16 6h12" stroke-linecap="round"/></svg>`,
  "Souris": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M24 6c-8 0-13 6-13 15v6c0 9 5 15 13 15s13-6 13-15v-6c0-9-5-15-13-15Z"/><path d="M24 6v14M17 14h14"/></svg>`,
  "Casques": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M8 28v-4a16 16 0 0 1 32 0v4"/><rect x="4" y="26" width="9" height="14" rx="3"/><rect x="35" y="26" width="9" height="14" rx="3"/></svg>`,
  "SSD & Stockage": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="8" y="14" width="32" height="20" rx="3"/><circle cx="16" cy="24" r="1.4" fill="currentColor" stroke="none"/><path d="M22 24h14" stroke-linecap="round"/></svg>`,
  "Chargeurs": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="14" y="6" width="20" height="26" rx="3"/><path d="M22 14h4l-3 6h4l-6 8v-6h-3l4-8Z" fill="currentColor" stroke="none"/><path d="M24 32v10m-5 0h10"/></svg>`,
  "Imprimantes": `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="10" y="16" width="28" height="14" rx="2"/><path d="M14 16v-8h20v8M14 34h20v8H14v-8Z"/><circle cx="32" cy="21" r="1.2" fill="currentColor" stroke="none"/></svg>`
};

const DEFAULT_ICON = DEVICE_ICONS["PC Portables"];

const products = [
  {
    id: 1,
    name: "HP EliteBook 840 G8",
    category: "PC Portables",
    price: 299000,
    oldPrice: null,
    rating: 5,
    stock: true,
    shortSpecs: ["Core i5-1135G7", "16 Go RAM", "SSD 512 Go"],
    specs: {
      "Processeur": "Intel Core i5-1135G7 (4 cœurs, jusqu'à 4.2 GHz)",
      "Mémoire RAM": "16 Go DDR4",
      "Stockage": "SSD NVMe 512 Go",
      "Écran": "14 pouces Full HD (1920x1080)",
      "Carte graphique": "Intel Iris Xe (intégrée)",
      "Autonomie": "Jusqu'à 9h",
      "État": "Reconditionné, grade A",
      "Garantie": "3 mois pièces et main d'œuvre"
    },
    description: "Ordinateur portable professionnel idéal pour la bureautique, les études et le multitâche. Châssis robuste, clavier confortable et autonomie fiable pour toute la journée."
  },
  {
    id: 2,
    name: "Dell Latitude 5420",
    category: "PC Portables",
    price: 349000,
    oldPrice: 379000,
    rating: 4,
    stock: true,
    shortSpecs: ["Core i7-1165G7", "16 Go RAM", "SSD 256 Go"],
    specs: {
      "Processeur": "Intel Core i7-1165G7 (4 cœurs, jusqu'à 4.7 GHz)",
      "Mémoire RAM": "16 Go DDR4",
      "Stockage": "SSD NVMe 256 Go",
      "Écran": "14 pouces Full HD (1920x1080)",
      "Carte graphique": "Intel Iris Xe (intégrée)",
      "Autonomie": "Jusqu'à 10h",
      "État": "Reconditionné, grade A",
      "Garantie": "3 mois pièces et main d'œuvre"
    },
    description: "Performance et mobilité pour les professionnels exigeants. Le Latitude 5420 combine puissance du i7 et finitions premium Dell."
  },
  {
    id: 3,
    name: "Lenovo ThinkPad X1 Carbon",
    category: "PC Portables",
    price: 499000,
    oldPrice: null,
    rating: 5,
    stock: true,
    shortSpecs: ["Core i7-10510U", "32 Go RAM", "SSD 1 To"],
    specs: {
      "Processeur": "Intel Core i7-10510U (4 cœurs, jusqu'à 4.9 GHz)",
      "Mémoire RAM": "32 Go LPDDR3",
      "Stockage": "SSD NVMe 1 To",
      "Écran": "14 pouces Full HD (1920x1080)",
      "Carte graphique": "Intel UHD Graphics",
      "Poids": "1.13 kg",
      "État": "Reconditionné, grade A+",
      "Garantie": "3 mois pièces et main d'œuvre"
    },
    description: "Le haut de gamme ThinkPad : ultra-léger, châssis en fibre de carbone, clavier légendaire. Fait pour les professionnels toujours en mouvement."
  },
  {
    id: 4,
    name: "PC Gamer FlexTech RTX 3060",
    category: "PC Gamer",
    price: 599000,
    oldPrice: 649000,
    rating: 5,
    stock: true,
    shortSpecs: ["Ryzen 5 5600", "16 Go RAM", "RTX 3060"],
    specs: {
      "Processeur": "AMD Ryzen 5 5600 (6 cœurs, jusqu'à 4.4 GHz)",
      "Mémoire RAM": "16 Go DDR4 3200 MHz",
      "Stockage": "SSD NVMe 512 Go",
      "Carte graphique": "NVIDIA RTX 3060 12 Go",
      "Alimentation": "600W 80+ Bronze",
      "Boîtier": "Verre trempé, ventilation RGB",
      "État": "Neuf, assemblé sur commande",
      "Garantie": "6 mois pièces"
    },
    description: "Configuration gaming assemblée par nos soins pour tourner les jeux récents en 1080p/1440p ultra sans compromis."
  },
  {
    id: 5,
    name: "PC Gamer FlexTech RTX 4060",
    category: "PC Gamer",
    price: 899000,
    oldPrice: null,
    rating: 5,
    stock: true,
    shortSpecs: ["Ryzen 7 5700X", "32 Go RAM", "RTX 4060"],
    specs: {
      "Processeur": "AMD Ryzen 7 5700X (8 cœurs, jusqu'à 4.6 GHz)",
      "Mémoire RAM": "32 Go DDR4 3600 MHz",
      "Stockage": "SSD NVMe 1 To",
      "Carte graphique": "NVIDIA RTX 4060 8 Go",
      "Alimentation": "650W 80+ Gold",
      "Boîtier": "Verre trempé, 4 ventilateurs ARGB",
      "État": "Neuf, assemblé sur commande",
      "Garantie": "6 mois pièces"
    },
    description: "Notre configuration la plus puissante : streaming, montage vidéo et gaming 1440p haute fréquence sans effort."
  },
  {
    id: 6,
    name: "HP EliteDesk 800 G4 Mini",
    category: "PC Bureau",
    price: 189000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["Core i5-8500T", "8 Go RAM", "SSD 256 Go"],
    specs: {
      "Processeur": "Intel Core i5-8500T (6 cœurs, jusqu'à 3.5 GHz)",
      "Mémoire RAM": "8 Go DDR4",
      "Stockage": "SSD 256 Go",
      "Format": "Mini PC compact",
      "Connectique": "USB-C, DisplayPort, HDMI",
      "État": "Reconditionné, grade A",
      "Garantie": "3 mois pièces et main d'œuvre"
    },
    description: "Format compact, encombrement minimal sur le bureau, parfait pour un poste de travail administratif fiable."
  },
  {
    id: 7,
    name: "Dell OptiPlex 7080 Tour",
    category: "PC Bureau",
    price: 245000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["Core i7-10700", "16 Go RAM", "SSD 512 Go"],
    specs: {
      "Processeur": "Intel Core i7-10700 (8 cœurs, jusqu'à 4.8 GHz)",
      "Mémoire RAM": "16 Go DDR4",
      "Stockage": "SSD NVMe 512 Go",
      "Format": "Tour, extensible",
      "État": "Reconditionné, grade A",
      "Garantie": "3 mois pièces et main d'œuvre"
    },
    description: "Une tour puissante et évolutive pour les métiers gourmands en ressources : compta, design léger, multitâche intense."
  },
  {
    id: 8,
    name: "Moniteur Dell 24\" Full HD",
    category: "Moniteurs",
    price: 79000,
    oldPrice: 89000,
    rating: 5,
    stock: true,
    shortSpecs: ["24 pouces", "Full HD", "IPS 75Hz"],
    specs: {
      "Taille": "24 pouces",
      "Résolution": "1920x1080 Full HD",
      "Dalle": "IPS, 75 Hz",
      "Connectique": "HDMI, VGA, DisplayPort",
      "État": "Neuf",
      "Garantie": "12 mois constructeur"
    },
    description: "Confort visuel au quotidien, couleurs fidèles et angles de vue larges grâce à la dalle IPS."
  },
  {
    id: 9,
    name: "Moniteur Gamer 27\" 144Hz",
    category: "Moniteurs",
    price: 149000,
    oldPrice: null,
    rating: 5,
    stock: true,
    shortSpecs: ["27 pouces", "144 Hz", "1ms"],
    specs: {
      "Taille": "27 pouces",
      "Résolution": "1920x1080 Full HD",
      "Fréquence": "144 Hz, 1ms",
      "Compatibilité": "FreeSync",
      "État": "Neuf",
      "Garantie": "12 mois constructeur"
    },
    description: "Fluidité maximale pour le gaming compétitif. Temps de réponse ultra-rapide, zéro déchirure d'image."
  },
  {
    id: 10,
    name: "Clavier mécanique RGB FlexTech",
    category: "Claviers",
    price: 22000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["Switches rouges", "Rétroéclairage RGB", "USB filaire"],
    specs: {
      "Type": "Mécanique, switches rouges linéaires",
      "Rétroéclairage": "RGB personnalisable",
      "Connexion": "USB filaire",
      "Disposition": "AZERTY",
      "État": "Neuf",
      "Garantie": "6 mois"
    },
    description: "Frappe précise et réactive avec un éclairage RGB personnalisable, idéal pour le gaming comme la bureautique."
  },
  {
    id: 11,
    name: "Souris gamer sans fil FlexTech",
    category: "Souris",
    price: 15000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["6400 DPI", "Sans fil", "6 boutons"],
    specs: {
      "Capteur": "Optique, jusqu'à 6400 DPI",
      "Connexion": "Sans fil 2.4 GHz",
      "Boutons": "6 programmables",
      "Autonomie": "Jusqu'à 40h",
      "État": "Neuf",
      "Garantie": "6 mois"
    },
    description: "Précision et liberté de mouvement sans câble, parfaite pour le gaming comme le travail quotidien."
  },
  {
    id: 12,
    name: "Casque gamer HyperSound X1",
    category: "Casques",
    price: 28000,
    oldPrice: 35000,
    rating: 5,
    stock: true,
    shortSpecs: ["Son surround 7.1", "Micro amovible", "USB/Jack"],
    specs: {
      "Son": "Surround virtuel 7.1",
      "Micro": "Amovible, réduction de bruit",
      "Connexion": "USB et Jack 3.5mm",
      "Coussinets": "Mousse à mémoire de forme",
      "État": "Neuf",
      "Garantie": "6 mois"
    },
    description: "Immersion sonore totale pour le gaming et confort longue durée grâce aux coussinets à mémoire de forme."
  },
  {
    id: 13,
    name: "SSD NVMe 512 Go Kingston",
    category: "SSD & Stockage",
    price: 32000,
    oldPrice: null,
    rating: 5,
    stock: true,
    shortSpecs: ["512 Go", "NVMe M.2", "Jusqu'à 3500 Mo/s"],
    specs: {
      "Capacité": "512 Go",
      "Interface": "NVMe M.2 PCIe 3.0",
      "Vitesse lecture": "Jusqu'à 3500 Mo/s",
      "Compatibilité": "PC portable et bureau",
      "État": "Neuf",
      "Garantie": "12 mois constructeur"
    },
    description: "Boostez votre machine : démarrage en quelques secondes, chargement instantané des applications."
  },
  {
    id: 14,
    name: "SSD SATA 1 To Crucial",
    category: "SSD & Stockage",
    price: 45000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["1 To", "SATA III", "560 Mo/s"],
    specs: {
      "Capacité": "1 To",
      "Interface": "SATA III 2.5 pouces",
      "Vitesse lecture": "Jusqu'à 560 Mo/s",
      "Compatibilité": "PC portable et bureau",
      "État": "Neuf",
      "Garantie": "12 mois constructeur"
    },
    description: "Grande capacité de stockage à prix accessible pour vos documents, photos et logiciels."
  },
  {
    id: 15,
    name: "Chargeur universel PC portable 90W",
    category: "Chargeurs",
    price: 12000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["90W", "8 embouts", "Compatible multi-marques"],
    specs: {
      "Puissance": "90W",
      "Embouts": "8 embouts inclus",
      "Compatibilité": "HP, Dell, Lenovo, Asus, Acer",
      "Protection": "Contre surtension et surchauffe",
      "État": "Neuf",
      "Garantie": "6 mois"
    },
    description: "Un seul chargeur pour toutes les marques courantes. Idéal en dépannage ou comme chargeur de secours."
  },
  {
    id: 16,
    name: "Imprimante HP LaserJet M141",
    category: "Imprimantes",
    price: 95000,
    oldPrice: null,
    rating: 4,
    stock: true,
    shortSpecs: ["Laser N&B", "Multifonction", "USB/Wifi"],
    specs: {
      "Type": "Laser monochrome multifonction",
      "Fonctions": "Impression, scan, photocopie",
      "Connectique": "USB, Wifi",
      "Vitesse": "Jusqu'à 22 pages/min",
      "État": "Neuf",
      "Garantie": "12 mois constructeur"
    },
    description: "Solution tout-en-un fiable pour le bureau ou la maison, impression rapide et économique."
  }
];

/* --------------------------------------
   Utilitaires
   -------------------------------------- */
function formatPrice(value) {
  return value.toLocaleString('fr-FR') + " FCFA";
}

function getWhatsAppLink(product) {
  const msg = `Bonjour FlexTech, je suis intéressé(e) par : ${product.name} (${formatPrice(product.price)}). Est-il disponible ?`;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
}

function getProductImageMarkup(product) {
  const icon = DEVICE_ICONS[product.category] || DEFAULT_ICON;
  return `
    <img src="assets/images/products/${product.id}.jpg" alt="${product.name}"
         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
    <div class="device-icon" style="display:none; align-items:center; justify-content:center;">${icon}</div>
  `;
}

function renderStars(rating) {
  return '★'.repeat(rating) + '☆'.repeat(5 - rating);
}

function renderProductCard(product) {
  const promo = product.oldPrice
    ? `<span class="badge badge-promo">Promo</span>`
    : '';
  const stockBadge = product.stock
    ? `<span class="badge badge-stock">En stock</span>`
    : `<span class="badge">Sur commande</span>`;

  return `
    <article class="product-card fade-in">
      <a href="produit.html?id=${product.id}" class="product-card-link">
        <div class="product-badges">
          ${stockBadge}
          ${promo}
        </div>
        <div class="product-image">
          ${getProductImageMarkup(product)}
        </div>
        <div class="product-info">
          <span class="product-cat">${product.category}</span>
          <h3 class="product-name">${product.name}</h3>
          <p class="product-specs">${product.shortSpecs.join(' • ')}</p>
          <div class="product-footer">
            <div>
              ${product.oldPrice ? `<span class="product-price-old">${formatPrice(product.oldPrice)}</span>` : ''}
              <span class="product-price">${formatPrice(product.price)}</span>
            </div>
            <div class="product-rating">${renderStars(product.rating)}</div>
          </div>
        </div>
      </a>
      <a href="${getWhatsAppLink(product)}" class="btn-whatsapp" target="_blank" rel="noopener">
        Commander sur WhatsApp
      </a>
    </article>
  `;
}

function displayProducts(productsArray, containerId, emptyMessage) {
  const container = document.getElementById(containerId);
  if (!container) return;

  if (productsArray.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="21" cy="21" r="13"/><path d="M30 30l10 10" stroke-linecap="round"/></svg></div>
        <h3>Aucun produit trouvé</h3>
        <p>${emptyMessage || "Essayez une autre recherche ou catégorie."}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = productsArray.map(renderProductCard).join('');

  const fadeElements = container.querySelectorAll('.fade-in');
  fadeElements.forEach(el => el.classList.add('visible'));
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('popular-products')) {
    displayProducts(products.filter(p => p.rating === 5).slice(0, 4), 'popular-products');
  }
  if (document.getElementById('promo-products')) {
    displayProducts(products.filter(p => p.oldPrice), 'promo-products');
  }
});
