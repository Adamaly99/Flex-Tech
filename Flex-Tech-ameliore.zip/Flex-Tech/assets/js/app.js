/* ========================================
   FLEXTECH — App JavaScript
   ======================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* --- Animation au défilement --- */
  const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

  // Ré-observe les éléments ajoutés dynamiquement (grilles produits)
  const gridObserver = new MutationObserver(() => {
    document.querySelectorAll('.fade-in:not(.visible)').forEach(el => observer.observe(el));
  });
  document.querySelectorAll('.products-grid').forEach(grid => {
    gridObserver.observe(grid, { childList: true });
  });

  /* --- Menu mobile --- */
  const menuToggle = document.querySelector('.menu-toggle');
  const navMenu = document.querySelector('#nav-menu');
  const navLinks = document.querySelectorAll('#nav-menu a');

  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', (!isExpanded).toString());
      navMenu.classList.toggle('nav-open');
      document.body.classList.toggle('nav-mobile-open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('nav-open');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-mobile-open');
      });
    });
  }

  /* --- Smooth scroll pour les ancres --- */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  /* --- Formulaire de contact --- */
  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = contactForm.querySelector('#name').value.trim();
      const message = contactForm.querySelector('#message').value.trim();
      const text = `Bonjour FlexTech, je m'appelle ${name}. ${message}`;
      window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`, '_blank');
      contactForm.reset();
    });
  }

  /* --- Page produits : filtre, recherche, tri --- */
  const productsPage = document.getElementById('all-products');
  if (productsPage) {
    let activeCategory = 'Tous';
    let searchTerm = '';
    let sortBy = 'default';

    const chips = document.querySelectorAll('.chip');
    const searchInput = document.querySelector('.search-input');
    const sortSelect = document.querySelector('.sort-select');
    const resultsCount = document.querySelector('.results-count');

    function applyFilters() {
      let result = products.filter(p => {
        const matchCat = activeCategory === 'Tous' || p.category === activeCategory;
        const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                             p.category.toLowerCase().includes(searchTerm.toLowerCase());
        return matchCat && matchSearch;
      });

      if (sortBy === 'price-asc') result.sort((a, b) => a.price - b.price);
      if (sortBy === 'price-desc') result.sort((a, b) => b.price - a.price);
      if (sortBy === 'name') result.sort((a, b) => a.name.localeCompare(b.name));

      displayProducts(result, 'all-products', 'Essayez une autre catégorie ou un autre mot-clé.');
      if (resultsCount) {
        resultsCount.textContent = `${result.length} produit${result.length > 1 ? 's' : ''} trouvé${result.length > 1 ? 's' : ''}`;
      }
    }

    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        activeCategory = chip.dataset.category;
        applyFilters();
      });
    });

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchTerm = e.target.value;
        applyFilters();
      });
    }

    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        sortBy = e.target.value;
        applyFilters();
      });
    }

    // Pré-sélection de catégorie via ?cat= dans l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const catParam = urlParams.get('cat');
    if (catParam) {
      const matchingChip = Array.from(chips).find(c => c.dataset.category === catParam);
      if (matchingChip) {
        chips.forEach(c => c.classList.remove('active'));
        matchingChip.classList.add('active');
        activeCategory = catParam;
      }
    }

    applyFilters();
  }

  /* --- Page fiche produit : rendu dynamique --- */
  const detailContainer = document.getElementById('product-detail-container');
  if (detailContainer) {
    const urlParams = new URLSearchParams(window.location.search);
    const id = parseInt(urlParams.get('id'), 10);
    const product = products.find(p => p.id === id) || products[0];

    document.title = `${product.name} | FlexTech`;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', product.description);

    const specsRows = Object.entries(product.specs)
      .map(([key, value]) => `<tr><td>${key}</td><td>${value}</td></tr>`)
      .join('');

    const oldPriceMarkup = product.oldPrice
      ? `<span class="product-detail-price-old">${formatPrice(product.oldPrice)}</span>`
      : '';

    detailContainer.innerHTML = `
      <div class="product-detail-image fade-in">
        ${getProductImageMarkup(product)}
      </div>
      <div class="product-detail-info fade-in">
        <span class="badge badge-lime">${product.category}</span>
        <h1>${product.name}</h1>
        <div class="product-rating">${renderStars(product.rating)}</div>
        <div class="product-detail-price-row">
          ${oldPriceMarkup}
          <span class="product-detail-price">${formatPrice(product.price)}</span>
        </div>
        <p class="product-desc">${product.description}</p>
        <table class="spec-table">${specsRows}</table>
        <div class="stock-note">
          <span class="stock-dot"></span>
          ${product.stock ? 'En stock — expédition sous 24 à 48h' : 'Disponible sur commande'}
        </div>
        <div class="product-detail-actions" style="margin-top:20px;">
          <a href="${getWhatsAppLink(product)}" class="btn-primary" target="_blank" rel="noopener">Commander sur WhatsApp</a>
          <a href="produits.html" class="btn-secondary">Retour aux produits</a>
        </div>
      </div>
    `;

    document.querySelectorAll('.fade-in').forEach(el => el.classList.add('visible'));

    // Produits similaires
    const relatedContainer = document.getElementById('related-products');
    if (relatedContainer) {
      const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);
      displayProducts(related, 'related-products', '');
    }
  }

  console.log('FlexTech chargé avec succès.');
});
